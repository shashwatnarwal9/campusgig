# Backend audit

## Structure and request lifecycle

`app/main.py` creates FastAPI, registers CORS and exception handlers, includes health and `/api/v1` routers, creates the local media root and mounts `/media` as `StaticFiles`. Routes mostly delegate to services; repositories hold SQLAlchemy queries. `get_db` yields a session from a global engine configured with `pool_pre_ping=True`; sessions are context-managed. No custom lifespan hook, shutdown disposal hook, background scheduler, structured logging configuration, metrics, or tracing setup was found.

## Authentication and authorization

Registration normalizes email and compares the exact configured domain in `auth_service.assert_institutional_email` (lines 36-48); account creation assigns STUDENT inside repository code. Email is not verified. Passwords use bcrypt cost 12. Registration requires 8 characters, a letter and digit, with bcrypt byte-length cap 72. Unknown users incur a dummy bcrypt operation. Existing users get an account-based lockout after configured failures. Session cookies are HttpOnly, SameSite=Lax, path `/`, Secure only when `ENVIRONMENT=production`; database stores SHA-256 token hashes and expiry. Logout deletes the matching session. Expired rows are rejected but no scheduled cleanup call to `session_repo.delete_expired` was found.

Ownership checks are service-side for applicant listing and status mutation. Request schemas omit poster ID/state and role, preventing those fields from being mass-assigned. Current role enum contains ADMIN but no admin router or role-management workflow exists.

## Routes (complete inventory in `api_inventory.csv`)

Router registration exposes health, auth, gigs, applications, and profile routes. `/health` is unversioned; all other app APIs use `/api/v1`. Authentication is required for all gig routes, profile routes, and `/auth/me`; register/login/logout are public, with logout idempotent if no token. Route-level expected statuses derive from declarations/domain handlers; unexpected errors use FastAPI defaults and may not follow the normal envelope.

## Business logic and validation

Gig listing validates page/page_size, query length, category enum, nonnegative budgets and allowed sort; service rejects inverted min/max. `GigCreate` enforces lengths, positive capped decimal budget, category, future deadline, duration range. Naive deadline values are interpreted as UTC. Repository uses parameterized SQLAlchemy expressions and deterministic ID tie-breaker, but uses ILIKE `%query%`, which will not use a conventional btree index and may become costly at scale. No benchmark exists.

Applications enforce one per gig/user in DB and catch duplicate IntegrityError. Allowed transitions are APPLIED→ACCEPTED/REJECTED and ACCEPTED→COMPLETED. Accept changes gig state and rejects pending alternatives before one commit. However, two requests can load separate APPLIED rows and both change to ACCEPTED because there is no row lock or DB constraint that limits a gig to one accepted application. This is a code-established race window, not a reproduced runtime finding.

## Database and migrations

Three linear PostgreSQL migrations define users/sessions/gigs, remove unused email verification, then add profile/application data. ORM and migrations appear broadly aligned in fields/types/constraints by source inspection. Important DB constraints include case-insensitive unique email, unique roll number, batch range, positive budget, title length, duration range, and unique application pair. No migration execution or live schema comparison occurred. Migrations use `citext`, `gen_random_uuid`, and generated email hash. Downgrades exist; reversibility was not exercised.

Potential subtlety: application accepted uniqueness is an application-layer assumption, not enforced in schema. `updated_at` uses mixin behavior (see `app/db/base.py`) and migration server defaults; trigger/update behavior should be confirmed for database-side updates.

## Upload/storage

`storage_service.py` uses magic bytes, random UUID names, incremental byte caps, and ignores the client filename. It does not decode/re-encode images or validate full file structure; PDF check verifies only the header. `main.py` serves the entire media directory publicly. A URL is effectively a bearer capability: anyone who obtains it can fetch a resume. Files live on local disk and will not be shared among multiple replicas. `_replace_file` commits the new path before best-effort old-file deletion; a failure can leave orphan files. No content hash is computed.

## Error handling/configuration/operations

Domain errors map to `{detail:{code,message}}`; validation adds `fields`; HTTP errors map to `http_<status>`. CORS uses configured origins, credentials, methods GET/POST/PATCH/OPTIONS and Content-Type only. Production refuses the sentinel auth secret, but no minimum secret length/entropy validation is performed for non-sentinel values. HTTPS is assumed by production Secure cookies; no reverse proxy/deployment config exists. Logs are basic INFO with standard format; sensitive logging was not found in examined paths. No rate-limit middleware, observability, or health readiness composition exists; `/health/db` tests DB only when called.

## Findings

See BE/SEC/DB IDs in `findings.csv`. Key actions: serialize acceptance on gig, consider one-winner database constraint, decide if public resume URLs meet privacy goals, add explicit deployment/storage requirements, and obtain the SRS before claiming compliance. No backend test or DB runtime reproduction was performed.
