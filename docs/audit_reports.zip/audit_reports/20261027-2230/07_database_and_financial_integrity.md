# Database and financial integrity audit

## Implemented schema

The three migrations define four current domain tables: `users`, `sessions`, `gigs`, `applications`. PostgreSQL UUID primary keys, case-insensitive `CITEXT` email uniqueness, generated `email_hash`, foreign keys, enum states, timestamp columns, and application uniqueness are used. Gigs use `NUMERIC(10,2)` budget rather than integer paise. This is exact fixed-scale decimal storage at the DB layer, with a maximum magnitude constrained indirectly by schema validation and precision. ORM and migrations appear substantially aligned by static inspection; no DB connection/schema introspection or migration run occurred.

Deletion rules: poster deletion restricted while gigs exist; sessions cascade with users; applications cascade with gig/user. Session expiry index exists, but expired rows are not periodically deleted in inspected runtime code. Query indexes include gig state+created_at, category, poster, application gig/applicant/status and sessions user/expiry.

## Implemented transaction boundaries

Registration commits user create and maps unique violations. Login commits session and resets counters. Applying commits application and database uniqueness catches duplicate requests. Status mutation updates accepted state, gig closure, and rejection of pending rows before one commit. However, no locking protects simultaneous status changes; application state is not guarded by a DB check/trigger. Thus atomicity within one transaction does not establish serializable single-winner semantics across concurrent requests.

Profile update commits DB path before deleting old media; file write precedes DB pointer commit. Failures can leave orphan files, while old file deletion failure is swallowed only through request error behavior depending on filesystem exception; there is no transaction spanning filesystem+DB.

## Planned financial functionality (not implemented)

No account, ledger transaction, ledger entry, escrow, contract, idempotency key, deliverable, dispute, rating, or settlement table/model exists. The project report sketches integer paise, balanced multi-entry transactions, append-only entries, deferred sum-to-zero checks, AVAILABLE/HELD balances, idempotency response replay, row locking and terminal contract states. These are design claims, not current schema or runtime behavior.

Before monetary features are enabled, the design should specify integer paise (or rigorously fixed decimal), per-transaction balancing invariant, append-only permissions, account ownership, unique idempotency scope/key, lock ordering, hold/release/refund/split transitions, prevention of double settlement, and reconciliation from immutable entries. None has been verified by executable constraints or tests here.

## Findings

- DB-001 / SEC-002: single accepted applicant not enforced under concurrency (High potential integrity).
- DB-002: monetary value display is budget only; no movement (Informational, correctly disclosed).
- DB-003: local media is outside relational transaction and may orphan; low operational integrity risk.
- DB-004: session cleanup path exists as repository method but no scheduler/caller was found; low storage-growth risk.

See findings register for evidence and remediation. No migration was run against any DB.
