# Test and runtime verification report

## Inventory

Backend: pytest suite under `backend/tests`: registration, auth/session, gigs, applications, profile, health/model; shared fixture applies Alembic migrations to a derived/configured test database and truncates tables between tests. Frontend: Vitest/Testing Library tests for auth and validation. Manifest scripts also include frontend typecheck, lint, build. Ruff is declared but no script is defined.

## Commands actually attempted

Commands were run from repository root using npm’s `--prefix frontend` behavior:

| Command | Outcome | Evidence/limitation |
|---|---|---|
| `npm --prefix frontend run typecheck` | Blocked, exit nonzero | Script invokes `tsc --noEmit`; `tsc: not found`. |
| `npm --prefix frontend run lint` | Failed due unavailable local tooling | `eslint` resolved to global 6.4.0 and reports it cannot find compatible configuration from `frontend/src`; project declares ESLint 9 flat config. |
| `npm --prefix frontend test -- --run` | Blocked, exit nonzero | `vitest: not found`. |
| `npm --prefix frontend run build` | Blocked, exit nonzero | First `tsc --noEmit` step fails: `tsc: not found`; Vite build did not run. |
| `python3 -m pytest --version` | Blocked, exit nonzero | `No module named pytest`. |
| `python --version` / `python -m pytest --version` | Blocked | `python: command not found`; `python3` is available. |
| `python3 --version` | Passed | Python 3.12.3. |
| `node --version`; `npm --version` | Passed | Node 18.19.1; npm 9.2.0. |
| `pdftotext -layout ProjectReport.pdf /tmp/campusgig_project_report.txt` | Passed | Extracted 942 lines; report says no performance benchmark. |
| `find .. -name CampusGigSRSv3.pdf -print` | No result | Named SRS absent in searched parent tree. |

No packages installed. Backend pytest not executed. Test fixture source (`backend/tests/conftest.py:69-100`) creates a DB if absent, runs `downgrade base`, applies migrations, truncates tables and deletes media. The configured `DATABASE_URL` and `TEST_DATABASE_URL` were not independently established as disposable, so no tests that could mutate a database were run.

## Verification state

- Backend tests: not run, dependencies unavailable; DB safety not established.
- Frontend tests: not run, Vitest unavailable.
- Frontend typecheck/build: not run successfully, TypeScript unavailable.
- Lint: incompatible global fallback attempted; project lint result unavailable.
- Migrations/schema checks: not run; no DB connection attempted.
- Runtime API/browser integration: not run.
- Performance: not run; ProjectReport explicitly says no benchmarking was done.

Tests are never reported as passing based on source inspection.
