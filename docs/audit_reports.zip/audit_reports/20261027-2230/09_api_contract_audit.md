# API contract audit

Routes registered by `app/api/v1/__init__.py` plus root health router are inventoried in `api_inventory.csv`, including static `/media` serving. API docs generated from FastAPI are available at `/docs` by default, but were not run. ProjectReport contains prose and route examples; the SRS named by user was unavailable, so documented-vs-actual SRS comparison cannot be complete.

Route inventory contains 19 API/static entries. Main frontend feature calls align with registered paths and methods. `GET /api/v1/gigs/mine` exists in client API module but no visible page call was found in the scanned UI. The static media mount is outside `/api/v1` and unauthenticated.

Error contract: domain errors provide stable codes; request validation returns code `validation_error` and fields; HTTP exceptions return `http_<status>`. Unexpected exceptions and Starlette static file responses may not match. Status codes are mostly explicit for creation and domain errors; login/logout/profile operations default to 200. There is no documented OpenAPI-specific snapshot test.

Security/contract notes: gig routes are all authenticated, including browse; ownership for applications is checked in service. Closed gig detail is visible only to poster. Applicant listing returns poster-safe applicant fields without email; public gig poster output exposes roll number, department and batch. Profile includes full email but only current authenticated user receives it. Resume static path is public.

No route supports gig update/delete, email verification, admin actions, bids, contracts, payments, deliverables or disputes. Those appear deferred in project plan. Do not treat them as missing current-scope routes until the SRS is available.
