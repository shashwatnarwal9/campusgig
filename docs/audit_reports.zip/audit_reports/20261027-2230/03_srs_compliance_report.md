# SRS-to-code compliance report

## Scope limitation

The named `CampusGigSRSv3.pdf` is unavailable. A true row-per-SRS-requirement compliance matrix is consequently impossible. The table below covers all 16 audit-local provisional themes extracted from available project documents; it is not a claim of full SRS traceability. Requirement count traced: 16 provisional document-derived themes, 0 verified SRS IDs.

## Provisional traceability matrix

| ID | Requirement summary | SRS location/status | Actual status | Evidence and gap | Severity / verification |
|---|---|---|---|---|---|
| DOC-001 | Whole-domain institutional signup | SRS unavailable; README/ProjectReport current | IMPLEMENTED, TEST GAP | `backend/app/services/auth_service.py:36-48`; `test_registration.py`; code compares full domain. Tests not executed. | Medium; run exact-domain and lookalike-domain cases. |
| DOC-002 | Email ownership proof | SRS unavailable; Report p.13 says removed | NOT IMPLEMENTED (documented removed) | Migration 0002 drops verification table/column; signup creates user directly. | Scope/security decision; confirm with actual SRS. |
| DOC-003 | Password storage/rules/lockout | SRS unavailable; Report pp.13-14 | IMPLEMENTED, TEST GAP | `core/security.py:12-27`; `schemas/auth.py:13-26`; `auth_service.py:80-112`; tests exist. No global IP throttling. | Medium; test plus rate-abuse review. |
| DOC-004 | Revocable session lifecycle | SRS unavailable; Report p.13 | IMPLEMENTED, TEST GAP | `deps.py:31-50`; `session.py`; `auth_service.py:115-126`; tests exist. Cookie Secure only in production. | Medium; test production cookie and expiration. |
| DOC-005 | Listing filters/sort/pagination | SRS unavailable; Report p.14 | IMPLEMENTED, TEST GAP | `api/v1/gigs.py:18-48`; `gig_repo.py:18-79`; frontend `GigsPage.tsx`; tests exist. | Medium; execute parameter matrix and edge cases. |
| DOC-006 | Gig creation and validation | SRS unavailable; Report p.14 | IMPLEMENTED, TEST GAP | `GigCreate`, `gig_service.create_gig`, `/gigs` POST; `test_applications.py` covers basic cases. No edit/close/delete endpoints. | Medium; compare all lifecycle requirements to SRS. |
| DOC-007 | Applications and uniqueness | SRS unavailable; Report pp.16-18 | IMPLEMENTED, TEST GAP | `application_service.py:32-52`; model unique constraint; duplicate test. | Medium; concurrency test not run. |
| DOC-008 | Poster state changes and single award | Report says current feature; sequence design p.15 includes lock not present | DEFECTIVE for single-winner concurrency guarantee | `application_service.py:87-110` has no lock; two requests can race; no unique accepted-gig constraint. | High potential integrity; reproduce concurrent accepts on isolated Postgres. |
| DOC-009 | Profile/file management | SRS unavailable; Report pp.16-18 | IMPLEMENTED, TEST GAP | `profile_service.py`; `storage_service.py`; `/profile` routes and UI. Media is public by opaque URL; disk storage is single-instance. | Medium; verify deployment and privacy expectations. |
| DOC-010 | Completed budget is not actual earnings | README/ProjectReport p.24 | VERIFIED IMPLEMENTED by code/docs, tests not run | `application_service.py:59-75`, Applied page disclaimer `AppliedGigsPage.tsx:108-110`. | Low; UI/API copy review. |
| DOC-011 | Bids/counteroffers | Deferred in plan/report | NOT IMPLEMENTED, planned | No bid model/service/routes; apply at fixed budget. | Not a current-scope gap unless SRS says otherwise. |
| DOC-012 | Contracts/escrow | Deferred | NOT IMPLEMENTED, planned | No contract/escrow models/routes/services. | Not a current-scope gap unless SRS says otherwise. |
| DOC-013 | Ledger and idempotency | Deferred | NOT IMPLEMENTED, design-only | No ledger tables or idempotency middleware. | Financial launch blocker if activated. |
| DOC-014 | Deliverables/disputes/ratings/admin | Deferred | NOT IMPLEMENTED, planned | No such models/routes/pages; role enum alone does not provide admin functionality. | Not a current-scope gap absent SRS. |
| DOC-015 | Performance target/measurement | No SRS available; ProjectReport says none measured | UNVERIFIED / no measurement | No benchmark files/config; report explicitly disclaims benchmark. | Medium if NFR exists; define and measure. |
| DOC-016 | File validation and access | SRS unavailable; Report pp.17-18 | PARTIALLY IMPLEMENTED | Signature + streamed size checks exist. Files served under public `/media`; no authenticated access/hash/re-encode. | Medium; validate content and privacy requirements. |

## Status summary (provisional rows only)

- Verified implemented: 1 (DOC-010; test evidence exists but was not run in this audit).
- Implemented, test gap: 6.
- Partially implemented: 1.
- Not implemented: 5 (two are explicitly removed/deferred, not current defects).
- Defective: 1.
- Unverified: 1.
- Not applicable: 0.

These counts describe the provisional catalog, not the absent SRS. Tests are present for many claims, but no test suite ran in this audit.

## Explicit risk-topic coverage

- Email domain exact match: implemented; ownership verification absent (migration 0002).
- Password: bcrypt cost 12; 8+ chars with letter and digit on registration; max bcrypt 72 bytes. Per-account lockout is 10 failures/15 minutes by defaults; no global/IP limiter. Dummy bcrypt for unknown account.
- Sessions: random opaque token, SHA-256 stored, DB expiry and logout deletion; HttpOnly/SameSite=Lax, Secure only for production. No cleanup scheduler for expired rows found.
- Roles: registration always assigns STUDENT; no admin routes/assignment workflow. ADMIN enum is not an admin feature.
- Ownership: application service verifies poster for listing/status; gig visibility limits closed gigs to owner. Public gig cards reveal roll number, department and batch; no email in PosterPublic.
- Gig edit/delete/close: no edit/delete API; closure occurs on acceptance.
- Filters: q/category/budgets/deadline/sort/page/page_size; inverted budget bounds rejected. Search uses parameterized SQLAlchemy ILIKE expression; wildcard characters are not escaped, affecting matching semantics rather than SQL injection.
- Application uniqueness: DB unique pair; status state machine. Concurrent accept race lacks row lock/unique accepted constraint.
- Atomic closure: state mutation and pending rejections in one transaction, but simultaneous acceptance safety not enforced.
- Contracts/escrow/ledger/idempotency/settlement/disputes/ratings/reconciliation: no implementation; explicitly deferred.
- Uploads: magic signature and size checked; random filenames; direct static serving makes any uploaded URL public. No hashing/virus scan/re-encoding; not required by current README but should be verified against SRS.
- Error envelope: centralized for domain, validation, HTTP exceptions. Static file responses and unexpected server errors are outside this envelope.
- Performance: no benchmark run; cannot verify any target.

CSV: `requirements_traceability.csv` contains the same 16 provisional rows and points back to report evidence.
