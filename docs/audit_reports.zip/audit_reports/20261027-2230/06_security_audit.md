# Security audit

Code-based, defensive review. No exploit attempts or external services were used. Confidence is stated per finding. Actual credentials are not reproduced.

## SEC-001 — Email address is not proven to belong to registrant

- Severity: Medium; confidence: High (behavior confirmed in code).
- Evidence: `backend/app/services/auth_service.py:36-48,51-77`; migration `0002_remove_email_verification.py`; frontend signup immediately redirects to login.
- Preconditions: Attacker can submit a syntactically valid `@thapar.edu` address they do not control.
- Scenario/impact: Account can be created under another student’s institutional address; there is no OTP/email ownership proof. Attacker may impersonate identity and claim gigs/applications associated with that account.
- Safe verification: In isolated test DB register an address not controlled by tester and observe account is created; do not use a real third-party address.
- Mitigation: If identity proof is required, restore verified email challenge and prevent use until verified. Confirm whether intentionally accepted by product scope.

## SEC-002 — Concurrent acceptance can violate one-winner invariant

- Severity: High potential integrity; confidence: High that lock/constraint absent, Medium for concurrent outcome without reproduction.
- Evidence: `backend/app/services/application_service.py:87-110`; no row lock in repositories/models; current tests exercise sequential accept only.
- Preconditions: Two poster requests concurrently accept different APPLIED applications for the same gig.
- Scenario/impact: Both may pass transition checks and commit ACCEPTED, since no row lock or unique accepted-per-gig constraint serializes them; each transaction may reject only still-APPLIED rows, potentially leaving two accepted workers.
- Safe verification: On disposable isolated Postgres, synchronize two requests after reading APPLIED, then inspect statuses. Do not test a production DB.
- Mitigation: Lock gig row before re-reading state and enforcing award, and/or database invariant enforcing one accepted application per gig. Add concurrent test.

## SEC-003 — Resume files are served publicly by opaque URL

- Severity: Medium; confidence: High.
- Evidence: `backend/app/main.py:69-73`; `storage_service.py:45-47`; `ProfilePage.tsx:219-225`.
- Preconditions: URL is disclosed, copied, logged, or exposed through browser history/referrer.
- Scenario/impact: Any holder can download a student resume without authentication; UUID unpredictability reduces discovery but does not enforce authorization.
- Safe verification: Upload a synthetic PDF in isolated environment and fetch its returned `/media/...` URL without a session.
- Mitigation: If resumes are private, use authenticated download endpoint with owner/applicant authorization and suitable cache/referrer policy. Keep public avatar separate.

## SEC-004 — Per-account lockout can be used for targeted denial of service; no global limiter found

- Severity: Medium; confidence: High for account lockout behavior, Medium for absence beyond inspected app.
- Evidence: `auth_service.py:80-85,91-101`; defaults in `core/config.py:30-32`; no rate middleware/config found.
- Preconditions: Attacker can send login requests for a known institutional email.
- Scenario/impact: Ten bad attempts lock target account for 15 minutes by default. Distributed or rotating account abuse has no evident IP/device throttling, increasing resource-exhaustion exposure.
- Safe verification: Existing account lockout test is designed to exercise it; do not target real accounts.
- Mitigation: Add carefully keyed IP/network throttling and alerting; avoid permanent attacker-controlled lockout policy.

## SEC-005 — File validation is signature/size based, not full decode/scanning

- Severity: Low/Medium; confidence: High.
- Evidence: `storage_service.py:31-38,72-84`; `main.py:73`.
- Preconditions: Authenticated user uploads a crafted file with recognized header.
- Scenario/impact: Polyglot/corrupt/oversized decompression payload risks depend on downstream browser and serving behavior; header-only PDF validation accepts malformed/non-PDF remainder. No demonstrated exploit.
- Safe verification: Upload synthetic malformed files in isolated scratch media and inspect served content; no active malware testing.
- Mitigation: Decode/re-encode images, enforce safer content-disposition/nosniff and scanning policy as required; use dedicated storage.

## SEC-006 — Production secret checks only reject one known default

- Severity: Low; confidence: High.
- Evidence: `backend/app/core/config.py:8-10,47-51`.
- Preconditions: Operator sets a weak/reused non-default `AUTH_SECRET` in production.
- Scenario/impact: Any future cryptographic use of secret is vulnerable to guessing; currently session tokens are random and stored hashed, so direct impact on current session mechanism is limited.
- Safe verification: Review deployment secret generation and secret-manager settings; no attempt to guess secret.
- Mitigation: Enforce minimum entropy/length or managed random secret and rotate securely.

## Other controls observed

bcrypt passwords; 72-byte cap; dummy verify for unknown users; parameterized SQLAlchemy; explicit CORS origin list with credentials (default localhost); HttpOnly, Lax cookie; backend auth dependency; schemas omit role/owner mass assignment; public poster schema omits email; React escapes interpolated text. No SQL injection or raw-HTML sink was identified in examined paths. CSRF is mitigated partially by SameSite=Lax and restrictive CORS but no CSRF token/origin check exists; security depends on deployment origin topology and browser behavior. No dependency vulnerability scan was possible or run. Admin functionality is absent; ADMIN enum alone does not expose privilege actions.

Additional race risk overlaps SEC-002. No destructive or external testing was performed.
