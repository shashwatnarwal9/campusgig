# Architecture and code quality

## Observed architecture

The implemented backend follows router/service/repository/model/schema layers with dependency injection for current user and DB session. Most business logic is outside route functions; repositories use SQLAlchemy query expressions. Error types are independent of FastAPI and mapped centrally. Frontend groups routes/pages, API modules, contexts/hooks, types and reusable UI components. This is a coherent small application architecture.

## Strengths evidenced in code

- Server-side session token hashes and explicit logout.
- Request schemas exclude privileged owner/state/role fields.
- DB uniqueness for accounts and applications, plus gig/user check constraints.
- Central error envelope and explicit CORS origin list.
- File names are random and client file names are ignored; file byte limits stream incrementally.
- Types are used across frontend and backend schemas; one fetch client centralizes credentials and error parsing.

## Risks and debt

- Application acceptance uses a multi-row state change without a lock or DB one-winner invariant; this is the largest correctness/integrity defect found.
- Uploads are served from a public static directory, and local-disk assumptions constrain deployment to shared storage/single instance.
- No deployment/CI config, migration automation policy, production topology, logging/metrics/tracing, or performance harness is included.
- `session_repo.delete_expired` has no observed caller.
- Gig query search is unindexed substring ILIKE and separate count/page queries; performance has not been measured.
- ORM/migration consistency was reviewed statically only; no autogenerate diff or live schema inspection.
- Product-level email verification intentionally absent in current docs; verify actual scope.
- README startup mentions Python 3.12, but test runner dependency is unavailable in current environment. Node manifest allows environment versions, but current Node is 18 and project scripts cannot resolve local dependencies.
- `git` metadata is unusable in this checkout, so change attribution and modified-file confirmation cannot use Git diff.

## Required before broader launch

1. Enforce one accepted application per gig under concurrent requests and add a regression test.
2. Decide and implement resume access policy; public URLs should be an explicit privacy decision.
3. Establish repeatable disposable test DB config, CI checks and test/build execution.
4. Define production secret, HTTPS, CORS, storage and backup/restore configuration.
5. Obtain actual SRS before compliance signoff.

Optional: add full-text search when data volume warrants; consolidate application summary/list queries if measured; add structured observability, cleanup job, focus trapping, and static analysis once toolchain is installed. No modifications were made.
