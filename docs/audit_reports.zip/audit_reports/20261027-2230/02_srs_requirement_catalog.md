# SRS requirement catalog

## Source availability

The specifically named `CampusGigSRSv3.pdf` is absent from the repository and was not found in the searched Desktop tree. Therefore the SRS cannot be read, and no exact SRS requirement identifiers, priorities, status labels, page citations, acceptance criteria, or complete requirement set can honestly be extracted. The entries below are a provisional catalog of explicit scope claims in README, PROJECT_PLAN, ARCHITECTURE, and ProjectReport.pdf. They are **not** a substitute for the SRS and must not be represented as its full contents.

`source_page` is populated only for the text-extractable Project Report. Requirement IDs below are audit-local IDs, not SRS IDs. PDF report text was extracted with `pdftotext -layout`; diagrams were not rendered and reviewed visually.

## Provisional requirement themes from available documents

- Current milestone: registration restricted by institutional email domain; password login; revocable HttpOnly session; gig browsing/search/filter/sort/pagination; gig posting; application and poster status workflow; profile bio/avatar/resume; honest earnings disclaimer.
- Explicitly deferred: email ownership verification (removed); bidding/counteroffers; contracts; escrow and ledger; deliverable upload; disputes/admin adjudication; ratings/reputation; payment gateway and reconciliation.
- Quality/security claims in available documents: backend validation and persistence; object ownership; unique applications; transition validation; uploaded-file signature and byte caps; consistent API error envelope; no performance testing reported.

Available ProjectReport describes nine UML diagrams: use cases, two class diagrams, contract state machine, two activity diagrams, three sequence diagrams; it also describes API tables, permission tables and schema design in prose. No independent page-image interpretation was performed. The detailed content may be useful design context but is not verified against `CampusGigSRSv3.pdf`.

## Contradictions and status cautions

ProjectReport says the full platform is designed and the initial implementation covers core milestones. README and PROJECT_PLAN say later features are intentionally out of current scope. This is a scope distinction rather than necessarily a contradiction. ProjectReport describes a planned lock-before-acceptance sequence, whereas current application code does not lock rows (see BE/DB findings). ProjectReport performance section explicitly says no benchmarking was performed.

See `requirements_catalog.csv` for machine-readable provisional entries. All SRS-specific fields are marked unavailable.
