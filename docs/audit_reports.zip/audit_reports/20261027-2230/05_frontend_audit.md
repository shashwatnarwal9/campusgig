# Frontend audit

## Application and routes

`src/main.tsx` mounts `App`; `AppRoutes.tsx` defines public signup/login guest routes and protected gig board/detail, applied dashboard, and profile routes. Route guards depend on client auth context; server `CurrentUser` remains the actual authorization boundary. AuthProvider loads `/auth/me`, and shared API client dispatches an unauthorized event on 401.

## API client and contract matching

`services/apiClient.ts` uses `fetch`, `credentials: include`, JSON serialization and FormData handling; base URL defaults to `http://localhost:8000`. Feature API files map to registered backend methods/paths. CORS credentials and frontend cookie use align for same-site localhost ports under development. Production deployment domains, HTTPS and SameSite behavior were not configured or verified. The API client assumes all successful bodies are JSON and all error bodies have `detail`; this is true for JSON application routes but not necessarily static media, unexpected errors, or future no-content routes.

No frontend calls exist for login/logout mismatched methods, and observed route paths align with backend definitions. UI does not expose admin, gig edit/delete, payments, bids, escrow, contracts, deliverables or disputes. This matches the declared current milestone.

## Functional UI behavior

- Signup and login have client validation; backend independently validates. Signup navigates to login and does not imply email verification.
- Gigs page supports query/category/budget/deadline/sort/page controls via `useGigs`; page resets are handled in UI. Posting sends normalized fields and ISO deadline.
- Gig detail displays public poster roll/dept/batch and controls application vs poster applicant list. Server enforces ownership.
- Applied page uses a single summary+list endpoint and filters locally by state; “Earned” is correctly qualified as completed gig value, not payment.
- Profile page edits bio and uploads avatar/resume; frontend resets file input to allow selecting same file.

## Risks/quality observations

`mediaUrl` prefixes relative media paths with API base. Browser can display public avatar URLs and open resume URLs in a new tab. No UI-side size/type checks were evident beyond `accept`; backend is authoritative. UI state prevents some repeated actions via loading flags, but server must remain idempotent. No broad e2e suite exists. Tests cover validation and auth provider only; frontend tests/build/typecheck were blocked by missing node dependencies.

Accessibility: labels and many ARIA states are present; modal has dialog semantics and Escape close, but focus trapping/restore was not evident. Error/loading/empty states exist across primary pages. Detail calls abort old requests on unmount/parameter change; applied list uses AbortController. No code-level XSS sink was identified in examined components: user-controlled text is rendered through React text interpolation, not raw HTML.

TypeScript compiler configuration exists but cannot be validated without `tsc`. Unused/dead code could not be comprehensively established via static lint because local ESLint dependency is absent; global ESLint 6.4 is incompatible with ESLint 9 flat config.

See FE findings in `findings.csv`. No frontend source changes or runtime execution beyond attempted manifest scripts occurred.
