# Independent reviewer handoff

## A. Executive summary

CampusGig is a university-restricted gig marketplace for Thapar Institute. The inspected build is a React 18/TypeScript SPA, FastAPI/Python 3.12 API, SQLAlchemy/Alembic PostgreSQL backend, and local disk media store. Implemented scope visible in code: registration with exact `@thapar.edu` domain check, bcrypt login, revocable server-side cookie sessions, gig browse/filter/post, applications with poster-driven status transitions, and student profile/avatar/resume. There is no email ownership verification, payment/escrow/ledger, contract, deliverable, dispute, rating, or administrator workflow. The latter are documented as deferred.

Readiness assessment: suitable for continued milestone development and isolated demo based on source structure, but not formally SRS-compliant (named SRS missing), not production-signoff ready from this audit, and not runtime-verified. Most significant code concern is concurrent acceptance of multiple applications because the update path has no row lock or database winner invariant. Resume files are public static resources. No money moves, clearly stated in UI/docs.

## B. Repository facts

Root: `/home/arham/Desktop/campusgig-main`. Git commands fail because `.git` is not recognized as a Git repository. Main backend `backend/app/main.py` (`app.main:app`); frontend `frontend/src/main.tsx`; database migrations under `backend/alembic/versions`. Startup commands in README: local Compose DB (`docker compose up -d db`), backend `uvicorn app.main:app --reload --port 8000` from backend, frontend `npm run dev` from frontend. Tests: backend `python -m pytest -q` (requires dedicated `*_test` database; fixture drops schema state via downgrade/truncate), frontend `npm run typecheck && npm run lint && npm test && npm run build`.

Configuration examples: backend `.env.example`, frontend `.env.example`. Database is PostgreSQL; local compose maps 5434. Never run fixture until TEST_DATABASE_URL/DATABASE_URL are confirmed disposable.

## C. SRS compliance

Named SRS not accessible. Therefore exact total requirement count and SRS-ID status breakdown are unknown. The audit traced 16 provisional themes from README, plan, architecture and ProjectReport; do not confuse those audit-local `DOC-*` IDs with SRS IDs. Provisional statuses: 1 verified by source/docs, 6 implemented with test gap, 1 partial, 5 not implemented (mostly explicitly deferred), 1 defective, 1 unverified. Largest mismatch against full-design prose is row locking/ledger behavior; actual plan defers financial workflows.

## D. Prioritized findings

- BE-001: concurrent application acceptance can violate one-winner rule; code evidence `backend/app/services/application_service.py:87-110`.
- SEC-002: uploaded resumes are served without authorization; `backend/app/main.py:69-73`, `backend/app/services/storage_service.py:45-47`.
- SEC-001: institutional domain check does not prove mailbox ownership; `backend/app/services/auth_service.py:36-48`; email verification migration removes schema.
- TEST-001: backend tests/frontend test/build/typecheck could not be run due missing dependencies and unknown-safe DB.
- SRS-001: missing `CampusGigSRSv3.pdf`; blocks formal compliance.
- SRS-002: no performance measurement; available report says so.

See `12_findings_and_remediation_roadmap.md` and `findings.csv` for full details.

## E. Evidence index

- Auth/session: `backend/app/services/auth_service.py`, `backend/app/core/security.py`, `backend/app/api/deps.py`, `backend/app/models/session.py`; tests `backend/tests/test_auth_session.py`, `test_registration.py`.
- Gig/application: `backend/app/services/application_service.py`, `backend/app/repositories/application_repo.py`, `backend/app/api/v1/gigs.py`, migrations; tests `backend/tests/test_applications.py`, `test_gigs.py`.
- Uploads: `backend/app/services/storage_service.py`, `backend/app/main.py`, `backend/app/services/profile_service.py`.
- Frontend routes/client: `frontend/src/routes/AppRoutes.tsx`, `frontend/src/services/apiClient.ts`, feature API modules and pages.
- Provisional scope/document sources: `README.md`, `PROJECT_PLAN.md`, `ARCHITECTURE.md`, `ProjectReport.pdf` pp.6-24 (text extracted; diagrams not visually audited).
- Reports: `03_srs_compliance_report.md`, `06_security_audit.md`, `07_database_and_financial_integrity.md`, `08_test_and_runtime_report.md`, `09_api_contract_audit.md`, `12_findings_and_remediation_roadmap.md`.

## F. Explicit unknowns

- Actual SRS requirements and diagram details; PDF absent.
- Git branch/status/history; `.git` unusable.
- Live DB schema, migration success/reversibility, runtime routes and tests.
- Production deployment, proxy controls, secrets, shared media, backup, monitoring, CI.
- Dependency vulnerabilities; no advisory scan was run.
- Visual diagram semantics; only captions/prose extracted.
- Whether external infrastructure provides rate limiting or deployment safeguards.

## G. Questions for independent reviewer

1. Does project scope intentionally accept accounts without email ownership verification, and is domain-only registration adequate for this deployment?
2. What database invariant best expresses one accepted worker per gig given the application state machine?
3. Should resumes be private to application participants, while avatars remain public?
4. Which performance targets and concurrency load belong in the authoritative SRS?
5. Do available ProjectReport designs impose requirements on the current milestone, or are they explicitly deferred by the plan?

This handoff states source-backed facts separately from blocked verification.
