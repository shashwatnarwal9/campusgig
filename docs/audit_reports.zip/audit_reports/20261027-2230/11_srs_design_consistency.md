# SRS design consistency review

## Limitation

`CampusGigSRSv3.pdf` was not found. The project report contains nine diagram descriptions and captions; diagrams were not visually rendered/inspected in this audit. The observations below compare report prose with actual source and must not be called SRS compliance results.

## Available design versus code

- Use-case scope includes verified students, employer/worker capacities, administrator, institutional mail, object store, scheduler; report says only registration, browse, posting, profile, and simplified apply are implemented. Source confirms no mail verification service, object storage client, scheduler, admin routes, or payment services.
- Domain class diagrams describe contracts, deliverables, status history, disputes, ratings, reputation, accounts, ledger transactions/entries, idempotency. Current ORM defines only User, UserSession, Gig, Application. ProjectReport explicitly identifies remaining classes as design-only.
- Contract state machine is not implemented; application state machine exists in `application_service.py` and is smaller. No contract trigger/ledger effect is present.
- Activity diagrams describe category screening, bid acceptance with row lock and escrow hold, then deliverables/revisions/timeouts/disputes. Current category is enum validation only; applying is fixed-budget; accept has no lock or ledger; completion is a poster-set status only.
- Sequence diagram acceptance flow describes idempotency lookup, transaction, row lock, re-read and balanced ledger. Code only verifies owner/status, then updates application/gig/other pending applications and commits; row lock/idempotency/ledger absent. This is a material design-to-code gap for the planned full platform and a concurrency risk even in the implemented one-winner award workflow.
- Report states design uses Long paise, but current `Gig.budget` and migration use `NUMERIC(10,2)`. This can be a reasonable current representation, but is a model inconsistency if same type is meant to be normative across the future financial system.
- ProjectReport says API contract docs should match OpenAPI; current code-generated OpenAPI follows registered routes, but no route snapshot/API contract test was found.
- Project report describes email OTP as once implemented then removed. Migration `0002` confirms removal from current schema.
- Report describes uploaded URLs as public capability links and notes this is unsuitable for private deliverables; current static mount confirms public access.

## Diagram-specific interpretation status

Use-case, context/DFD L0 and L1, class/domain, activity/swimlane, sequence, and state machine images were not independently inspected. Prose references to them were extracted from ProjectReport.pdf, especially pp.6-17. Arrow direction/include/extend semantics, actor placement, and exact diagram labels remain unverified. No exact SRS page numbers are available.
