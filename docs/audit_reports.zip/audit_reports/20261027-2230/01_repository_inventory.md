# Repository inventory

Audit date: 2026-10-27 (Asia/Kolkata). Repository root observed: `/home/arham/Desktop/campusgig-main`.

## Repository state and limits

- `git status --short --branch` and `git rev-parse --show-toplevel` both fail with `fatal: not a git repository`, although a small `.git/` directory exists. Branch, tracked/untracked state, and clean-diff verification are therefore unavailable.
- No `AGENTS.md` was found. No existing `audit_reports/` directory existed before this audit. No `CampusGigSRSv3.pdf` was found in the checkout or Desktop search locations.
- `ProjectProposal.pdf` (10 pages) and `ProjectReport.pdf` (28 pages) are present and text-extractable. They were reviewed as project documents, not treated as the missing SRS.
- Hidden `.agents`, `.aws`, `.codex` directories contain no visible files in the inventory. No credential values were copied into this report.

## Directory tree (source/config/docs; generated and dependencies excluded)

```text
.
├── .gitattributes, .gitignore
├── ARCHITECTURE.md, PROJECT_PLAN.md, README.md
├── ProjectProposal.pdf, ProjectReport.pdf
├── docker-compose.yml
├── backend/
│   ├── .env.example, pyproject.toml, alembic.ini
│   ├── alembic/{env.py,script.py.mako,versions/0001..0003}
│   ├── app/{main.py,api,core,db,models,repositories,schemas,seeds,services}
│   └── tests/{conftest.py,test_*.py}
└── frontend/
    ├── .env.example, package.json, package-lock.json, vite.config.ts, tsconfig.json, eslint.config.js
    ├── index.html, public/categories/*
    └── src/{App.tsx,main.tsx,components,context,hooks,layouts,lib,pages,routes,services,styles,types,__tests__}
```

The detailed file list was collected with `rg --files --hidden`; the repository contains 104 regular project files (including image assets, PDFs, lockfiles, and this audit package; count excludes `.git` internals and generated output). Approximate source/config/docs breakdown: backend 48, frontend 45, root docs/config/PDF 8, assets 9 (overlap avoided only approximately due to directory categorization). Hidden files in `.git` could not be interpreted as a valid Git database.

## Stack and versions

- Backend manifests: Python `>=3.12`, FastAPI `>=0.115`, SQLAlchemy `>=2.0.36`, psycopg 3, Alembic `>=1.14`, Pydantic v2, bcrypt, pytest/httpx/Ruff dev dependencies.
- Database: PostgreSQL, README claims PostgreSQL 15+; Compose specifies `postgres:17-alpine` for local development.
- Frontend manifests: React 18, TypeScript `^5.6.3`, Vite `^5.4.11`, React Router 6, Vitest 2, Framer Motion 11, ESLint 9.
- Runtime observed: Python 3.12.3, Node 18.19.1, npm 9.2.0. No `frontend/node_modules` and no `backend/.venv`; global pytest is absent.

## Entry points and startup

- Backend app: `backend/app/main.py`, ASGI target `app.main:app`; README starts with `uvicorn app.main:app --reload --port 8000` from `backend/`.
- Frontend: `frontend/src/main.tsx` mounts React; `frontend/src/App.tsx` and `src/routes/AppRoutes.tsx`; README uses `npm run dev`.
- Database: root `docker-compose.yml` exposes local Postgres on host port 5434; README backend example separately names a URL using port 5434.
- Migrations: `backend/alembic/versions/0001_initial_schema.py` through `0003_applications_and_profile.py`.

## Architecture and module responsibilities

Backend request path is FastAPI routers → service rules → repository SQLAlchemy queries → ORM models/PostgreSQL; Pydantic schemas shape requests and responses. Session auth is a database-backed opaque token in an HttpOnly cookie. Frontend uses React Router, context-based auth/profile state, a shared fetch wrapper, feature API modules, and page/components. Uploaded files are local disk paths under `MEDIA_ROOT` and mounted under `/media`.

Key modules: `app/api/v1/{auth,gigs,applications,profile,health}.py`; `app/services/{auth,gig,application,profile,storage}_service.py`; `app/repositories/*`; `app/models/{user,session,gig,application}.py`; `app/schemas/*`; frontend `src/pages`, `src/services`, `src/context`, `src/routes`.

## Test inventory

Backend pytest files: registration, auth/session, gigs, applications, profile, health/model, plus shared `conftest.py`. Frontend Vitest files: validation and auth UI. These are code inventory only; current audit could not run backend tests, frontend tests, typecheck, or build due to missing dependencies. The backend fixture creates a derived or configured test DB, downgrades it to base, upgrades migrations, truncates tables, and deletes scratch media; it was not run because the DB target could not be independently established as disposable.

## Configuration and uninspected areas

Examples exist at `backend/.env.example` and `frontend/.env.example`; no real `.env` files appeared in the file listing. Runtime secrets and DB endpoints remain environment-dependent. No CI workflow, deployment manifest, reverse proxy, frontend e2e suite, performance harness, or production storage service is present in the inspected tree. `pdfinfo`/`pdftotext` were available; PDF text was extractable for project documents. Diagram visual details were not independently rendered/inspected in this audit, so diagram semantics below are limited to report captions and accompanying prose. Git state remains unverified.
