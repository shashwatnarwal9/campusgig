# Findings register and remediation roadmap

Detailed machine-readable rows and locations are in `findings.csv`. Findings are consolidated to avoid counting the same acceptance race twice: BE-001 is the root defect; SEC-002 focuses separate privacy exposure.

## Prioritized findings

### High priority

- **BE-001 — Concurrent accepts can produce multiple winners** (High potential integrity; high confidence guard is absent). `application_service.py:87-110`; sequential tests do not cover races. Add transaction serialization and a database invariant, then test concurrent requests on isolated PostgreSQL.
- **SRS-001 — Missing named SRS** (High signoff blocker). No formal requirement traceability is possible until authoritative `CampusGigSRSv3.pdf` is supplied.

### Medium priority

- **SEC-001 — Email ownership is not verified** (Medium, high confidence). Exact domain is checked but mailbox control is not; scope decision required.
- **SEC-002 — Public resume URLs** (Medium, high confidence). Static `/media` is unauthenticated; change if resume privacy is required.
- **SEC-003 — Account lockout without evident global rate limit** (Medium, medium confidence).
- **DB-002 — Local media deployment/orphan risk** (Medium, high confidence).
- **TEST-001 — Tests/builds could not run** (Medium, high confidence).
- **SRS-002 — Performance not measured** (Medium, high confidence).
- **ARCH-001 — No CI/deployment/observability files in checkout** (Medium; external infrastructure unknown).

### Low and informational

- **SEC-004 — Production secret validation only rejects sentinel** (Low).
- **DB-001 — Expired session cleanup has no observed caller** (Low).

## Roadmap

1. Obtain `CampusGigSRSv3.pdf` and confirm current vs deferred scope before compliance signoff.
2. Fix single-winner application acceptance with locking/database invariant; verify a concurrent race using isolated Postgres.
3. Decide identity-proof and resume privacy requirements; implement controls if required.
4. Establish disposable database configuration and run backend migrations/tests plus frontend typecheck/lint/tests/build in CI.
5. Define production secret, HTTPS, CORS, shared media, backup, logging and monitoring configuration.
6. Define actual performance objectives from SRS and measure them. Keep future escrow/ledger outside current readiness claims until implemented with accounting invariants and retry safety.

All verification methods above are recommendations; none of those tests were run in this audit.
